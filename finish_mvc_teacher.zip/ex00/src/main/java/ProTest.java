import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class ProTest {
	public static void main(String[] args) {

		String driver="oracle.jdbc.OracleDriver";
//oracle.jdbc는 패키지명, OracleDriver는 jdbc 드라이버 클래스명
String url="jdbc:oracle:thin:@localhost:1521:xe";
//데이터베이스 접속 주소, 1521은 포트번호,xe는 디비명
String user="night";//오라클 접속 사용자
String password="1234";//오라클 접속 비번

    Connection con=null;//오라클연결 참조변수 선언
    CallableStatement cs=null;//저장프로시저 실행 참조변수
    PreparedStatement pt=null;//쿼리문 실행 참조변수
    ResultSet rs=null;//검색 결과 자료를 저장할 참조변수
    String sql=null;//쿼리문 저장변수
    
    try {
Class.forName(driver);//오라클 jdbc드라이버 클래스 로드
con=DriverManager.getConnection(url, user, password);
//오라클 연결 객체 생성
//System.out.println("오라클연결 성공");
Scanner sc=new Scanner(System.in);//System.in은 키보드 입력장
//치와 연결,입력받기 위한 sc객체 생성
System.out.println("방명록 번호 입력=>");
int g_no=Integer.parseInt(sc.nextLine());
sql="select * from guest where g_no=?";
pt=con.prepareStatement(sql);//쿼리문 실행 객체 생성
pt.setInt(1,g_no);
rs=pt.executeQuery();//검색 쿼리문 실행해서 결과 레코드를 
//rs에 저장

if(rs.next()) {//검색 결과 번호가 있는 경우
  sql="{call sel_guest(?,?,?,?)}";//저장 프로시저 호출 쿼리문
  cs=con.prepareCall(sql);//저장 프로시저 실행 객체 생성
  cs.setInt(1,g_no);//첫번째 물음표에 정숫 숫자로 번호값 저장
  
  cs.registerOutParameter(2,java.sql.Types.VARCHAR);
  cs.registerOutParameter(3,java.sql.Types.VARCHAR);
  cs.registerOutParameter(4,java.sql.Types.VARCHAR);
  //출력 결과물에 대한 타입 설정
  
  cs.execute();//저장 프로시저실행
  System.out.println("no \t name \t title \t cont");
  System.out.println("------------------------------>");
  System.out.println(g_no+"\t"+cs.getString(2)+"\t"+
  cs.getString(3)+"\t"+cs.getString(4));
}else {
System.out.println("검색번호가 없어서 저장프로시저 실행못함!");
}
    }catch(Exception e) {e.printStackTrace();}
    finally {
    	try {
    		if(cs != null) cs.close();
    		if(rs != null) rs.close();
    		if(pt != null) pt.close();
    		if(con != null) con.close();
    	}catch(Exception e) {e.printStackTrace();}
    }
	}//finally
}



