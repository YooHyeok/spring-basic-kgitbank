package org.zerock.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.zerock.domain.SampleVO;

@RestController
/* 1.REST는 'Representational State Transfer' 의 약어이다.최
 * 근에는 서버에 접근하는 기기의 종류가 다양해 지면서 기기에서 공통
 * 으로 데이터를 처리할 수 있는 규칙을 만들려는 시도가 REST방식
 * 이다. REST방식의 서비스 제공이 가능한 것을 'Restful'이라고 
 * 한다.
 * 2.REST방식의 서비스를 구현하기 위해서는 스프링 3.0버전부터는
 * @ResponseBody 애너테이션을 사용하였고,스프링 4.0부터는
 * @RestController로 서비스를 제공하고 있다.jsp파일을 만들어서
 * 뷰를 생성하는 것이 아니라 단순문자열,xml,JSON(키,값) 같은 객체
 * 데이터가 바로 웹브라우저에서 만들어 지고 출력된다.하지만 IE
 * 계열 웹브라우저에서는 잘 실행되지 않는다.
 */
@RequestMapping("/sample")
//컨트롤 자체 매핑주소 /sample 등록
public class SampleController4 {

	@RequestMapping("/hello")
	//메서드 실행시 등록되는 /hello매핑주소 등록
	public String sayHello() {
		return "Hello World!";//웹브라우저에 문자열 출력
		//출력되는 파일 형태가 text/html이다.(각 브라우저 개발도
		//구:단축키 F12)
	}
	
	@RequestMapping("/sendVO")
	public SampleVO sendVO() {
		SampleVO vo=new SampleVO();
		vo.setFirstName("홍");
		vo.setLastName("길동");
		vo.setMno(11);
		
	    return vo;//JSON데이터가 반환. SampleVO클래스의 변수명
	    //이 키이름이 된다.
	}
	
	@RequestMapping("/sendList")
    public List<SampleVO> sendList(){
		List<SampleVO> list=new ArrayList<>();
		//뒷부분 <>제네릭 타입 생략가능한 것은 jdk1.7이후부터
		//가능함.
		for(int k=1;k<=10;k++) {
			SampleVO vo=new SampleVO();
			vo.setMno(k);
			vo.setFirstName("홍"); vo.setLastName("길동");
			list.add(vo);//컬렉션에 추가
		}//for
		return list;
	}//sendList()
	
	//키,값 Map타입으로 JSON 출력
	@RequestMapping("/sendMap")
	public Map<Integer,SampleVO> sendMap(){
		Map<Integer,SampleVO> map=new HashMap<>();
		for(int i=1;i<=10;i++) {
			SampleVO vo=new SampleVO();
			vo.setMno(i);
			vo.setFirstName("홍");
			vo.setLastName("길동");
			map.put(i, vo);//맵 키,값 저장
		}//for
		return map;
	}//sendMap()
	
	@RequestMapping("/sendErrorAuth")
	public ResponseEntity<Void> sendListAuth(){
/* 1. @RestController는 별도의 뷰페이지를 제공하지 않는 형태로
 * 서비스를 실행하기 때문에 결과 데이터에 예외 적인 상황 문제가
 * 발생한다. 웹의 경우는 Http 상태코드 정보를 뜻한다.
 * 2.상태코드 종류
 *  가. 100 : 현재 데이터가 처리중인 상태
 *  나. 200 : 정상적인 응답
 *  다. 300 : 다른 url 처리
 *  라. 400(404):해당 폴더에 파일 또는 자원없음 상태
 *  마. 500 : 서버 내부 문제		
 * 3.스프링에서 제공하는 ResponseEntity 타입은 결과데이터+
 * HTTP상태코드를 제어할 수 있는 클래스 이다.결국 상태코드와 결과
 * 데이터를 함께 전송해서 좀더 세밀한 제어가 필요한 경우 사용한다 
 */
     return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
     //웹브라우저 응답 상태코드가 400발생(각 브라우저에서 F12
     //단축키를 눌러서 400상태를 확인할 수 있다.)
	}
	
	@RequestMapping("/sendErrorNot")
	public ResponseEntity<List<SampleVO>> sendListNot(){
		List<SampleVO> list=new ArrayList<>();
		for(int k=1;k<=10;k++) {
			SampleVO vo=new SampleVO();
			vo.setMno(k);
			vo.setFirstName("이");
			vo.setLastName("순신");
			list.add(vo);
		}
		return new ResponseEntity<List<SampleVO>>(
				list,HttpStatus.NOT_FOUND);
		//결과 페이지와 404전송(해당 자원 없다),@RestController
//방식을 주로 사용하는 곳이 예를 들어 안드로이드,아이폰과 같은
//모바일 환경의 HTML5,AJAX등에 이용하는 경우에 많이 사용된다.		
	}//sendListNot()
}

























































































