package org.zerock.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.zerock.domain.ProductVO;

@Controller //@Controller애너테이션을 사용하면 implments 
//Controller를 하지않아도 쉽게 스프링에서 인식할 수 있는 컨트롤
//클래스를 만들 수 있다.
public class SampleController2 {

	@RequestMapping("/doC")
	//웹주소에서 /doC 매핑주소가 실행될때 호출
	public String doC(@ModelAttribute("msg") String name) {
// doC?msg=값 웹주소창에서 노출된 get방식(쿼리스트링방식)으로
//msg피라미터이름에 값을 담아서 전달하면 name매개변수에 저장		
		System.out.println(name);
		return "result"; // /WEB-INF/views/result.jsp
	}
	
	@RequestMapping("/doD")
	public String doD(Model m) {
		ProductVO p=new ProductVO("수박",15000);
		
		m.addAttribute(p);
		//p객체를 저장하면 productDetail.jsp파일에서 표현언어로
		//변수값을 가져올때 ProductVO클래스 첫글자를 영문소문자로
		//해서 ${productVO.name} 처리한다.
		return "productDetail";
	}
	
	@RequestMapping("/doE")
    public ModelAndView doE(Model m) {
		
		ProductVO p=new ProductVO("레몬",7000);
		
		m.addAttribute("p",p);//p문자열 키이름에 Object타입으로
		//업캐스팅 된 p객체를 저장
		ModelAndView dm=new ModelAndView();
		dm.setViewName("shop/p2");
		// WEB-INF/views/shop/p2.jsp 파일명
		return dm;
	}
	
	@RequestMapping("/doF")
	public ModelAndView doF() {
		ProductVO p=new ProductVO("사과",1000);
		ModelAndView m=new ModelAndView("shop/p2");
		m.addObject("p",p);//p키이름에 p객체를 저장
		return m;
	}
	
	@RequestMapping("/doG")
	public String doG(HttpServletRequest request) {
		ProductVO p=new ProductVO("딸기",5000);
		request.setAttribute("p",p);
		return "shop/p2";
	}
}




























