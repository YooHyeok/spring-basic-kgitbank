package org.zerock.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller //@Controller 애노테이션을 활용하면 implements 
//Controller 자바 코드를 하지 않아도 스프링에서 인식되는 컨트롤
//클래스를 쉽게 만들수 있다.
public class SampleController {

	private static final Logger logger=
			LoggerFactory.getLogger(SampleController.class);
	//sts 개발툴 콘솔모드에 로그 기록을 남기기 위해서 logger객체
	//를 생성함
	
	@RequestMapping("doA")//@RequestMapping 애너테이션 get  or
	//post등으로 접근하는 매핑주소(url-patter:웹주소에서 실행되는
	//주소값)를 인식해서 해당 메서드를 처리하게 한다. doA가 매핑
	//주소이다.
	public void doA() {
		logger.info("doA 매핑주소가 호출됨");
		//콘솔모드에서 로그 문자열이 출력된다. 뷰페이지 파일명을
		//지정하지 않고 반환값이 없는 void형이면 jsp파일명은
		//매핑주소가 된다.즉 doA.jsp
	}
	
   @RequestMapping("/doB")
   public ModelAndView doB() {
	   return new ModelAndView("dob_test");
	   //WEB-INF/views/dob_test.jsp 뷰페이지 파일이 실행됨.
   }
}


























