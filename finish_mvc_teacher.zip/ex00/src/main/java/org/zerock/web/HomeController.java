package org.zerock.web;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		//serverTime키이름에 날짜 포맷값을 저장
		return "home";// /WEB-INF/views/home.jsp파일 실행
	}
	
	//댓글 테스트 매핑
	@RequestMapping(value="/test",
			method=RequestMethod.GET)
	//get으로 접근하는 매핑주소 /test 처리
	public void ajaxText() {
	//리턴타입이 없는 경우는 매핑주소가 jsp파일명 이 된다.	
	}	
}






















