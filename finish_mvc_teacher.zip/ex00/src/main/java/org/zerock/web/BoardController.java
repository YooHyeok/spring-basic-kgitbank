package org.zerock.web;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.zerock.domain.BoardVO;
import org.zerock.service.BoardService;

@Controller //@Controller 애노테이션으로 스프링에 컨트롤 클래스
//를 등록
@RequestMapping("/board/*") //컨트롤 클래스 입장의 매핑주소를 등
//록.  웹주소 경로는 /web/board/매핑주소
public class BoardController {

	@Inject
	private BoardService boardService;
	
	//게시판 글쓰기 폼매핑작업
	@RequestMapping(value="/board_write",
			method=RequestMethod.GET)
	//GET방식으로 접근하는 매핑주소를 처리하는 애노테이션 설정
	//POST방식 매핑 처리 안됨.
	public void board_write(HttpServletRequest request,
			Model m) throws Exception{
		//리턴타입 없는 경우는 매핑주소가 jsp파일명이 된다.
		//뷰페이지 경로가 /WEB-INF/views/board/board_write.jsp
		int page=1;
		if(request.getParameter("page") != null) {
page=Integer.parseInt(request.getParameter("page"));			
		}
		m.addAttribute("page",page);
		//page키이름에 쪽번호 저장
	}//board_write()
	
	//게시물 저장 매핑처리
	@RequestMapping(value="/board_write",
			method=RequestMethod.POST)
	//board_write.jsp에서 action 속성을 지정하지 않은 경우
	//현재 매핑주소가 바로 action속성의 매핑주소가 된다.
	//같은 매핑주소를 구분할때는 get or post로 구분한다.
	public String board_write_ok(BoardVO board,
			RedirectAttributes rttr) throws Exception{
	//BoardVO board를 사용하면 네임피라미터 이름과 빈클래스 변수
//명이 같을때 스프링이 자동으로 이름이 같은 피라미터 모든 데이터를
//board객체를 수집한다.		
		this.boardService.insertBoard(board);//게시물저장
		rttr.addFlashAttribute("msg","SUCCESS");
//리다이렉트(다른 매핑주소로 이동) 되는 시점에 딱 한번만 사용되는
//데이터를 보내고 msg키이름에 저장된 자료는 웹주소창에 노출안됨.		
		return "redirect:/board/board_list";
		//목록보기 매핑으로 이동
	}
	
	//게시판 목록보기 매핑
	@RequestMapping(value="/board_list",
			method=RequestMethod.GET)
	public void board_list(Model model,
			HttpServletRequest request,
			@ModelAttribute BoardVO b) throws Exception{
	/* 1. 메서드 반환 타입이 void이면 매핑주소가 jsp파일명이 된
	 * 다.그러므로 뷰페이지 경로는 /WEB-INF/views/board/board_
	 * list.jsp가 된다.
	 * 2. Model model을 선언한 이유는 키,값 쌍으로 저장하기 위
	 * 해서 이다.
	 * 3.@ModelAttribute BoardVO b 라고 여기서만 사용한 이유는
	 * BoardVO 의 새로운 객체 b가 생성한 효과가 발생한다.	
	 */
		int page=1;
		int limit=10;//한페이지 보여지는 목록개수를 10으로 제한
		if(request.getParameter("page") != null) {
page=Integer.parseInt(request.getParameter("page"));
//get으로 전달된 쪽번호를 정수 숫자로 바꿔서 저장
		}
		int totalCount=this.boardService.getRowCount();
		//게시물 총 레코드 개수
		//System.out.println("총 게시물수:"+totalCount);
		
		b.setStartrow((page-1)*10+1);//시작행 번호,예를 들어
//한페이지 보여지는 목록개수를 5개로 제한할려면 10->5로 수정
		b.setEndrow(b.getStartrow()+limit-1);//끝행번호
		
		//페이징 목록
		List<BoardVO> blist=this.boardService.getList(b);
		//System.out.println(blist.size()+"개");
		
		//총페이지수
		int maxpage=(int)((double)totalCount/limit+0.95);
		//현재 페이지에 보여줄 시작페이지(1,11,21..)
int startpage=(((int)((double)page/10+0.9))-1)*10+1;
        //현재 페이지에 보여줄 마지막 페이지
        int endpage=maxpage;
        
        if(endpage>startpage+10-1) endpage=startpage+10-1;
        
		model.addAttribute("blist",blist);
		//blist키이름에 blist객체를 저장
		model.addAttribute("page",page);
		model.addAttribute("startpage",startpage);
		model.addAttribute("endpage",endpage);
		model.addAttribute("maxpage",maxpage);
		model.addAttribute("totalCount",totalCount);
	}
	
	//내용보기+조회수 증가
	@RequestMapping(value="/board_read",
			method=RequestMethod.GET)
	public ModelAndView board_read(
			@RequestParam("bno") int bno,
			@RequestParam("page") int page) throws Exception{
/* 1. @RequestParam("bno") 이것은 서블릿 자바코드로 표현하면
 * 	request.getParameter("bno");랑 같다.
 */
		//this.boardService.updateHit(bno);//조회수 증가
		//BoardServiceImpl에서 트랙잭션을 적용하기 위해서 주석
		BoardVO b=this.boardService.getBoardCont(bno);
		//번호에 해당하는 게시물 내용을 가져옴.
		String b_cont=b.getContent().replace("\n","<br/>");
//textarea 태그영역내에서 엔터키 친부분을 다음줄로 줄바꿈처리		
		
		ModelAndView cm=new ModelAndView("board/board_cont");
		//생성자 인자값으로 뷰페이지 폴더 경로를 설정
        cm.addObject("b",b);
        cm.addObject("b_cont",b_cont);
        cm.addObject("page",page);//각 키이름에 값을 저장
		return cm;
	}	
	
	//게시물 수정폼 매핑
	@RequestMapping(value="/board_edit",
			method=RequestMethod.GET)
	public ModelAndView board_edit(
	@RequestParam("bno") int bno) throws Exception{
		BoardVO b=this.boardService.getBoardCont(bno);//번호
//에 해당하는 디비 레코드 값을 가져옴.
		ModelAndView em=new ModelAndView();
		em.setViewName("board/board_edit");//뷰페이지 경로
		em.addObject("b",b);
		return em;
	}
	
	//게시판 수정 완료
	@RequestMapping(value="/board_edit",
			method=RequestMethod.POST)
	//post방식일때 처리하는 매핑주소
	public String board_edit_ok(
			@ModelAttribute BoardVO eb,
			RedirectAttributes rttr) throws Exception{
/* 1.@ModelAttribute BoardVO eb 라고 사용하면 네임피라미터이름
 * 과 빈클래스 변수명이 같은 경우 일대 일 매핑(대응)이 되어져서
 * 저장된다.eb객체에 저장됨. BoardVO eb라고 사용해도 된다.
 * 2.rttr을 사용하면 리다이렉트시 키이름에 값을 전달할 수 있다.
 * 웹주소창에 노출안된다.
 */
		this.boardService.editBoard(eb);//번호를 기준으로
		//작성자,제목,내용을 수정
		rttr.addFlashAttribute("msg","SUCCESS");//msg키이름
		//에 SUCCESS문자열 저장
		return "redirect:/board/board_list";
	}
	
	//게시물 삭제
	@RequestMapping("/board_del")
	//get or post 방식 모두 매핑주소를 처리
	public ModelAndView board_del(
			@RequestParam("bno") int bno,
			RedirectAttributes rttr) throws Exception{
	this.boardService.deleteBoard(bno);//번호를 기준으로 게시
	//물 삭제
	rttr.addFlashAttribute("msg","SUCCESS");
	return new ModelAndView("redirect:/board/board_list");
	}
}



































































