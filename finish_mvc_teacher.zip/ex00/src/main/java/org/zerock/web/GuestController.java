package org.zerock.web;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.zerock.domain.GuestVO;
import org.zerock.service.GuestService;

@Controller
public class GuestController {
	
	@Inject
	private GuestService gService;

	//방명록 글쓰기 폼
	@RequestMapping(value="/gu_write",
			method=RequestMethod.GET)
	//get으로 접근하는 매핑주소를 처리
	public ModelAndView gu_write() {
		return new ModelAndView("gu/gu_write");
		//뷰페이지 폴더 경로 /WEB-INF/views/gu/gu_write.jsp
	}
	
	//방명록 저장
    @RequestMapping(value="/gu_ok",
    		method=RequestMethod.POST)
    public ModelAndView gu_ok(@ModelAttribute GuestVO g) {
    	//네임피라미터 이름과 도메인빈클래스 변수명이 일치하면
    	//g객체에 벌써 이름,제목,비번,내용이 저장됨.
    	this.gService.insertGu(g);//this. 생략 가능
    	//방명록 저장
    	return new ModelAndView("redirect:/gu_list");
    	//새로운 매핑주소 gu_list로 리다이렉트
    }
    
    //목록보기 매핑
    @RequestMapping(value="/gu_list",
    		method=RequestMethod.GET)
    public String gu_list(Model m) {
      List<GuestVO> glist=this.gService.getList();//목록
      
      m.addAttribute("glist",glist);
      return "gu/gu_list";// /WEB-INF/views/gu/gu_list.jsp
    }
    
    //내용보기
    @RequestMapping(value="/gu_cont",
    		method=RequestMethod.GET)
    public ModelAndView gu_cont(
    		@RequestParam("g_no") int g_no) {
//@RequestParam("g_no")의 뜻은 request.getParameter("g_no");
//와 같다.
    	//System.out.println(g_no);
    	GuestVO g=this.gService.getCont(g_no);
    	
    	ModelAndView cm=new ModelAndView();
    	cm.addObject("g",g);//g키이름에 g객체를 저장
    	cm.setViewName("gu/gu_cont");
    	return cm;
    }
    
    //삭제폼
    @RequestMapping(value="/gu_del",
    		method=RequestMethod.GET)
    //하이퍼링크,location,redirect,sendRedirect,개발자가 직접
    //웹주소창에서 매핑주소를 입력하는 모두다 get방식(쿼리스트링).
    public ModelAndView gu_del(HttpServletRequest request) {
    	int g_no=
   	Integer.parseInt(request.getParameter("g_no"));
    	
 return new ModelAndView("gu/gu_del").addObject("g_no",g_no);
    }
}
























































