package org.zerock.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.io.IOUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.zerock.util.MediaUtils;
import org.zerock.util.UploadFileUtils;

@Controller
public class UploadController {
	
	@Resource(name="uploadPath")
	private String uploadPath;//이진파일 업로드 경로 리소스 설정

	//파일 업로드 폼
	@RequestMapping(value="/uploadForm",
			         method=RequestMethod.GET)
	//get방식으로 접근하는 매핑주소를 처리
	public void uploadForm() {}
	//명확한 jsp파일명이 없고,리턴타입이 없는 경우는 매핑주소가
	//jsp파일명이 된다.즉 uploadForm.jsp
	
	
	@RequestMapping(value="/uploadFormOK",
			         method=RequestMethod.POST)
	//post방식으로 접근하는 매핑주소를 처리
    public String uploadFormOK(MultipartFile file,
    		Model m) throws Exception{
	/* 1.Multipart로 첨부된 파일은 servlet-context.xml에 설정한
	 * multipartResolver 설정을 통해서 처리된다.
	 * 2. MultipartFile에 의해서 첨부된 파일을 처리하게 된다.
	 */
System.out.println("첨부한 원래 파일명:"+
	 file.getOriginalFilename());
System.out.println("파일 크기:"+file.getSize());
System.out.println("파일 타입:"+file.getContentType());

String savedName=uploadFile(file.getOriginalFilename(),
		file.getBytes());//바뀌어진 이진파일명을 저장
  
        m.addAttribute("savedName",savedName);//키,값 쌍으로
        //저장
        return "uploadResult";// /WEB-INF/views/uploadResult
        //.jsp로 설정
	}//uploadFormOK()
	
	private String uploadFile(String originalName,
			byte[] fileData) throws Exception{
		UUID uid=UUID.randomUUID();//UUID는 암호 강도의 높은
//의사 난수를 생성하게 한다.
		String savedName=uid.toString()+"_"+originalName;
		//바뀌어진 이진파일명(UUID 중복되지 않는 고유한 키값_
		//원래파일명:중복파일명이 거의 발생안함)
		File target=new File(uploadPath,savedName);
		
		FileCopyUtils.copy(fileData, target);//upload폴더에
		//바뀌어진 첨부파일명으로 실제 업로드
		return savedName;
	}
	
	//비동기식 아작스 이진파일 업로드 폼 매핑
	@RequestMapping(value="/uploadAjax",
			method=RequestMethod.GET)
	//GET방식으로 접근하는 매핑주소를 처리하는 애너테이션
	public void uploadAjax() {}
	//리턴타입이 없고(void), 명확한 jsp파일명이 없는 경우는 매핑
	//주소가 바로 jsp  뷰페이지 파일명이 된다.
	
	@ResponseBody
	//이 애노테이션은 스프링 3.0 이후부터 지원하면서 본격적인
	//REST 방식의 처리를 지원한다.이것을 사용하면 쉽게 비동기식
	//아작스로 json 데이터를 처리할 수 있다.
	@RequestMapping(value="/uploadAjax",
	method=RequestMethod.POST,
	produces="text/plain;charset=UTF-8")
	//produces속성을 지정하면 한글을 정상적으로 전송하기 위한것
	public ResponseEntity<String> uploadAjax(
			MultipartFile file) throws Exception{
System.out.println("첨부한 원래 파일명:"+
			file.getOriginalFilename());
System.out.println("파일크기:"+file.getSize());
System.out.println("파일타입:"+file.getContentType());

return new ResponseEntity<>(
		UploadFileUtils.uploadFile(uploadPath,
				file.getOriginalFilename(),
				file.getBytes()),
		HttpStatus.CREATED);//http상태코드가 CREATED 정상적
//으로 처리생성(==HttpStatus.OK)
	}//uploadAjax	
	
	//일반 파일인 경우는 원본파일명으로 다운로드가 되고, 'jpg',
	//'gif','png' 인 이미지 인경우는 브라우저에 해당이미지가
	//직접 보여주게 한다.
	//파일 전송방식=>브라우저로 전송받고자 하는 파일명을 get으로
	//전송한다.( /displayFile?fileName=/년/월/일/파일명)
	@ResponseBody //byte[]배열이 그대로 전송
	@RequestMapping("/displayFile") // get or post 방식 모두
	//처리하는 매핑주소
	public ResponseEntity<byte[]> displayFile(
			String fileName) throws Exception{
		InputStream in=null;
		ResponseEntity<byte[]> entity=null;
		System.out.println("fileName:"+fileName);
		
		try {
String formatName=fileName.substring(
		fileName.lastIndexOf(".")+1);//첨부파일 확장자
MediaType mType=MediaUtils.getMediaType(formatName);
//이미지 파일인지 아닌지를 판단
HttpHeaders headers=new HttpHeaders();
in=new FileInputStream(uploadPath+fileName);

       if(mType != null) {//이미지 파일이면
    	   headers.setContentType(mType);//적절한 타입을 지정
       }else {//이미지 아닌 경우
fileName=fileName.substring(fileName.indexOf("_")+1);
//_이후부터 마지막 문자까지 구하면 바로 원본파일명이 된다.
headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
//브라우저에게 자동으로 다운로드 창을 만들어 준다.
headers.add("Content-Disposition",
		"attachment;filename=\""+
new String(fileName.getBytes("UTF-8"),"ISO-8859-1")+"\"");
//한글 파일은 다운로드 될때 파일이름이 깨지기 때문에 반드시 인코
//딩을 해야한다.
       }//if else
       entity=new ResponseEntity<byte[]>(
    		   IOUtils.toByteArray(in),
    		   headers,HttpStatus.CREATED);
//IOUtils.toByteArray()은 대상파일로 부터 데이터를 읽는다.       
		}catch(Exception e) {
			e.printStackTrace();
entity=new ResponseEntity<byte[]>(HttpStatus.BAD_REQUEST);			
		}finally {
			in.close();
		}//finally 문이 예외와 상관없이 무조건 마지막에 실행
		return entity;
	}//displayFile()
	
	//첨부파일 삭제
	@ResponseBody
	@RequestMapping(value="/deleteFile",
	method=RequestMethod.POST)
	public ResponseEntity<String> 
	deleteFile(String fileName){
		System.out.println("삭제할 파일명:"+fileName);

String formatName=
fileName.substring(fileName.lastIndexOf(".")+1);//첨부파일
//확장자
MediaType mType=MediaUtils.getMediaType(formatName);
//파일 타입 체크. 특히 이미지 파일 확장자 타입 체크
if(mType != null) {//이미지 파일이면
	String front=fileName.substring(0,12);//0이상 12미만 사이
	//문자 반환 => /년/월/일
	String end=fileName.substring(14);//썸네일 이미지 인 경우
	// 's_'를 뺀 파일명만 구함
	new File(uploadPath+(front+end).replace('/',
			File.separatorChar)).delete();
	// 경로를 /로 바꾸면서 폴더로 부터 파일 삭제
}
new File(uploadPath+fileName.replace('/',
		File.separatorChar)).delete();
		return new ResponseEntity<String>("deleted",
				HttpStatus.OK);
	}
}



























































