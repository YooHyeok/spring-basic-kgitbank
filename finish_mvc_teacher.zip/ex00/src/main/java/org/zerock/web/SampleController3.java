package org.zerock.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.zerock.domain.ProductVO;

@Controller
public class SampleController3 {

	@RequestMapping("/send")
	public String send(RedirectAttributes rttr) {
		rttr.addFlashAttribute("msg","This is seven");
		//새로운 매핑주소로 리다이렉트시(이동시) 웹주소창에 노출
		//되지 않게 msg키이름에 값을 담아서 전달한다.
		return "redirect:/sendF";//sendF 매핑주소로 이동		
	}
	
	@RequestMapping("/sendF")
	public void sendF(@ModelAttribute("msg") String name) {
		//msg로 전달된 값을 받아서 name매개변수에 저장
		System.out.println("전달된 값:"+name);
		/* 1.메서드 반환 타입이 void형 인경우는 매핑주소가 뷰페
		 * 이지 파일명이 된다.즉 sendF.jsp 
		 */
	}
	
	//스프링 컨트롤에서 json데이터 만드는 법(키,값)
	@RequestMapping("/doJSON")
	public @ResponseBody ProductVO doJSON() {
	//스프링 컨트롤 클래스에서 json데이터를 생성하기 위해서는
	//@ResponseBody 애노테이션을 추가한다.	
    //매핑주소를 실행할때 ie계열 웹브라우저에서 실행하면 결과값이
	//키,값 쌍으로 웹브라우저에 출력되지 않고 json파일을 다운로드
	//를 받게 되니 주의요망. jsp파일을 만들지 않아도 키,값 쌍으로
	//웹브라우저에 출력됨.
		ProductVO p=new ProductVO("샘플상품",30000);
		//ProductVO 클래스의 변수명이 JSON데이터의 키이름이 됨
		return p;
	}
}











































