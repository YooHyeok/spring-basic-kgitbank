package org.zerock.web;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.zerock.domain.MessageVO;
import org.zerock.service.MessageService;

@RestController //스프링에서 jsp파일을 만들지 않고,문자열,xml,
//요즘은 거의 json 테이터 객체를 만들기 위한 애노테이션(REST방식)
@RequestMapping("/messages")
//컨트롤 클래스에 매핑주소 등록
public class MessageController {

	@Inject
	private MessageService service;
	
    @RequestMapping(value="/",method=RequestMethod.POST)
    public ResponseEntity<String> addMessage(
    		@RequestBody MessageVO vo){
//@RequestBody는 json으로 전송된 자료를 MessageVO 타입 객체로
//변환한다.그러므로 키이름이 변수명과 같아야 한다.
    	ResponseEntity<String> entity=null;
    	try {
          service.addMessage(vo);//메시지 추가    		
entity=new ResponseEntity<>("SUCCESS",HttpStatus.OK);          
    	}catch(Exception e) {
    		e.printStackTrace();
entity=new ResponseEntity<>(e.getMessage(),
		HttpStatus.BAD_REQUEST);    		
    	}
    	return entity;
    }
}















