package org.zerock.web;

import java.util.List;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.zerock.domain.ReplyVO;
import org.zerock.service.ReplyService;

@RestController
@RequestMapping("/replies")
public class ReplyController {

	@Inject
	private ReplyService replyService;
	
	//댓글등록
	@RequestMapping(value="",method=RequestMethod.POST)
	//post방식으로 접근하는 매핑주소를 처리
	public ResponseEntity<String> register(
			@RequestBody ReplyVO vo){
//@RequestBody는 전송된 JSON 데이터를 객체로 변환해 주는 애노테
//션이다. 이 애너테이션을 사용하면 데이터 전송방식은 JSON 포맷을
//사용한다. json으로 보내진 데이터를 ReplyVO타입의 객체로 변환
//해준다.
		ResponseEntity<String> entity=null;
		try {
		this.replyService.addReply(vo);//댓글등록
entity=new ResponseEntity<String>("SUCCESS",HttpStatus.OK);
//성공한 경우 SUCCESS문자열 반환
		}catch(Exception e) {
          e.printStackTrace();
entity=new ResponseEntity<String>(e.getMessage(),
		HttpStatus.BAD_REQUEST);//댓글달기에 실패하면 예외
//에러 원인 메시지를 전송하고,사용자 에게는 상태코드가 BAD_REQUES
//T 즉 400 결과를 전송한다.
		}
		return entity;
	}//register()
	
	//해당 게시물번호에 대한 전체 댓글목록
	@RequestMapping(value="/all/{bno}",
			method=RequestMethod.GET)
	//GET으로 접근할 때 매핑주소를 처리
	public ResponseEntity<List<ReplyVO>> list(
			@PathVariable("bno") int bno){
//@PathVariable 애노테이션은 웹주소 경로에서 원하는 자료를 추출
//하는 용도로 사용.여기서는 {bno} 에 주어진 게시물 번호값을 가져와
//int bno에 저장
		ResponseEntity<List<ReplyVO>> entity=null;
		try {
entity=new ResponseEntity<>(
this.replyService.listReply(bno),HttpStatus.OK);//게시물 번호
//에 대한 전체 댓글 목록,정상 성공시 상태코드가 200이 전송
		}catch(Exception e) {
			e.printStackTrace();
	    entity=new ResponseEntity<>(HttpStatus.BAD_REQUEST);	
		}
		return entity;
	}//list()

  //댓글 수정
  @RequestMapping(value="/{rno}",
method= {RequestMethod.PUT,RequestMethod.PATCH})
  //PUT은 전체자료를 수정,PATCH는 일부 자료를 수정,복수개의 
  //메서드 방식을 지정함
  public ResponseEntity<String> update(
		  @PathVariable("rno") int rno,
		  @RequestBody ReplyVO vo){
	  ResponseEntity<String> entity=null;
	  
	  try {
		  vo.setRno(rno);//댓글번호를 기준으로 수정하기 위해서
		  //댓글번호 저장
		  replyService.editReply(vo);//댓글 수정
entity=new ResponseEntity<String>("SUCCESS",
		HttpStatus.OK);		  
	  }catch(Exception e) {
		  e.printStackTrace();
entity=new ResponseEntity<String>(e.getMessage(),
		HttpStatus.BAD_REQUEST);		  
	  }
	  return entity;
  }//update()
  
  //댓글 삭제
  @RequestMapping(value="/{rno}",
		  method=RequestMethod.DELETE)
  public ResponseEntity<String> remove(
		  @PathVariable("rno") int rno){
	  
	  ResponseEntity<String> entity=null;
	  try {
		 this.replyService.delReply(rno);//댓글 삭제
entity=new ResponseEntity<String>("SUCCESS",
		HttpStatus.OK);//삭제 성공시 SUCCESS문자열이 전달되고
//200상태코드가 전달된다.
	  }catch(Exception e) {
		  e.printStackTrace();
entity=new ResponseEntity<>(e.getMessage(),
		HttpStatus.BAD_REQUEST);		  
	  }
	  return entity;
  }//remove()
}

























