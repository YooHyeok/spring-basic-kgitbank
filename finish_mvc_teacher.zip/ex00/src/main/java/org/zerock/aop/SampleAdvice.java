package org.zerock.aop;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component //스프링의 빈으로 인식하기 위해서 설정
@Aspect //aop기능을 하는 클래스 선언부에 추가
public class SampleAdvice {

	private static final Logger logger=
			LoggerFactory.getLogger(SampleAdvice.class);
	//로그 기록하는 객체 생성
	
	//@Before(
//"execution(* org.zerock.service.MessageService*.*(..))")
//@Before Advice타입은 해당메서드를 먼저 실행한 후 target메서드
//가 실행되게 하는 것.PointCut 지정하는 문법으로 AspectJ 언어
//문법을 사용한다. org.zerock.service.MessageService로 시작하는
//모든 클래스의 모든(*)  메서드를 지정하는 포인트 컷이란 여러 메서
//드 중 실제 aop Advice가 적용될 대상 메서드
   public void startLog(JoinPoint jp) {
		logger.info("---------------------");
		logger.info("---------------------");
		logger.info(Arrays.toString(jp.getArgs()));
//getArgs()는 전달되는 모든 피라미터들을 Object[]배열로 가져온다.		
	}
	
	//@Around(
//"execution(* org.zerock.service.MessageService*.*(..))")
//@Around AOP Advice타입은 가장 강력하게 사용할 수 있는 것으로
//말 그대로 메서드의 실행 전체를 앞,뒤로 감싸서 특정한 기능을 실행
//할 수 있다. 즉 target 메서드 호출전,호출후 모두 가장 광범위하게
//사용됨
	public Object timeLog(ProceedingJoinPoint pjp)
	throws Throwable{
//ProceedingJoinPoint는 JoinPoint의 하위 인터페이스이다.그러므
//로 조인포인트의 모든 메서드를 가짐.@Around타입의 반환타입은 
//Object이어야 하고 메서드를 직접 호출하고,결과를 반환해야만 정상
//상적인 처리가 된다.
		long startTime=System.currentTimeMillis();//현재시간값
logger.info(Arrays.toString(pjp.getArgs()));//전달되는 모든
//피라미터들을 Object[]배열로 반환
Object result=pjp.proceed();//다음 Advice를 실행하거나,실제 tar
//get객체의 메서드를 실행
long endTime=System.currentTimeMillis();//끝나는 시간값
logger.info(pjp.getSignature().getName()+"경과 시간: "+
(endTime-startTime));
logger.info("============================");
		return result;
	}
}







































