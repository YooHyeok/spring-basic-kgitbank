package org.zerock.persistence;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import org.zerock.domain.MessageVO;

@Repository
public class MessageDAOImpl implements MessageDAO {

	@Inject
	private SqlSession sqlSession; //mybatis쿼리문 실행 객체
	//에 자동의존성 주입
	
	@Override
	public void create(MessageVO vo) {
		sqlSession.insert("m_in2",vo);
		//insert id명 m_in
	}
}






