package org.zerock.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import org.zerock.domain.BoardVO;

@Repository
public class BoardDAOImpl implements BoardDAO {

	@Inject
	private SqlSession sqlSession;//자동 의존성 주입하고
	//mybatis 쿼리문 실행 객체 sqlSession 생성

	@Override
	public void insertBoard(BoardVO b) {
		this.sqlSession.insert("b_in",b);
		//insert() mybatis에서 레코드 저장메서드,b_in은 board.
		//xml에서 설정할 insert 아이디명,물론 중복아이디명이 있어
		//면 안된다.
	}//게시물 저장

	@Override
	public List<BoardVO> getList(BoardVO b) {
		return this.sqlSession.selectList("b_list",b);
		//mybatis에서 selectList()메서드는 하나이상의 자료를 디
		//비로 부터 검색해서 컬렉션 List로 반환
		//b_list는 select 아이디명
	}//목록보기

	@Override
	public int getRowCount() {
		return this.sqlSession.selectOne("b_count");
		//mybatis에서 selectOne()메서드를 사용하면 단 한개의
		//레코드만 반환할 때 사용.b_count는 select아이디명.
	}//총레코드 개수

	@Override
	public void updateHit(int bno) {
		this.sqlSession.update("b_hit",bno);
		//mybatis에서 update()메서드는 레코드를 수정한다.
		//b_hit는 update 아이디명.
	}

	@Override
	public BoardVO getBCont(int bno) {
		return this.sqlSession.selectOne("bcont", bno);
//selectOne()은 단 한개의 레코드만 검색, bcont는 select 아이디명
//중복 아이디명이 있어면 안된다.		
	}//내용보기

	@Override
	public void editBoard(BoardVO eb) {
		this.sqlSession.update("bedit",eb);
		//update()가 mybatis에서 수정메서드,bedit는 update아이디
		//명
	}//게시물 수정

	@Override
	public void deleteBoard(int bno) {
		this.sqlSession.delete("bdel",bno);
		//bdel은 delete 아이디명,delete()메서드로 레코드삭제
	}//게시물 삭제

	@Override
	public void updateReplyCnt(int bno, int amount) {
		Map<String,Object> pm=new HashMap<>();
		//키,값 쌍으로 저장하는 컬렉션 구조,제네릭 선언
		
		pm.put("bno",bno); //board.xml매퍼 태그에서 키이름을
		//참조해서 게시물 번호값을 가져옴.
		pm.put("amount",amount);
		sqlSession.update("updateReplyCnt",pm);
		//updateReplyCnt는 update아이디명.update()메서드로
		//레코드 수정한다.
	}//댓글 카운터 추가
}



























