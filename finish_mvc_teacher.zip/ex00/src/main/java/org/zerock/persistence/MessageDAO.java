package org.zerock.persistence;

import org.zerock.domain.MessageVO;

public interface MessageDAO {

	void create(MessageVO vo);//메시지기록 추상메서드
}
