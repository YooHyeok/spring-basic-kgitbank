package org.zerock.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import org.zerock.domain.ReplyVO;

@Repository
public class ReplyDAOImpl implements ReplyDAO {

	@Inject
	private SqlSession sqlSession;//mybatis 쿼리문 실행 객체
	//생성

	@Override
	public void addReply(ReplyVO vo) {
	  this.sqlSession.insert("reply_in",vo);
	  // reply_in은 reply.xml에서 설정할 insert 아이디명
	}//댓글등록	

	@Override
	public List<ReplyVO> listReply(int bno) {
		return sqlSession.selectList("reply_list",bno);
		//selectList()는 mybatis 하나이상의 레코드를 검색해서
		//컬렉션 List로 반환,reply_list는 select 아이디명
	}//댓글목록

	@Override
	public void editReply(ReplyVO vo) {
		sqlSession.update("reply_edit",vo);
		//댓글 수정,reply_edit는 update 아이디명
	}

	@Override
	public void delReply(int rno) {
		sqlSession.delete("reply_DEL",rno);
		//reply_DEL delete 아이디명
	}//댓글 삭제

	@Override
	public int getBno(int rno) {
		return this.sqlSession.selectOne("reply_bno",rno);
	}//댓글에서 게시물 번호 알아내기
}













