package org.zerock.persistence;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class PointDAOImpl implements PointDAO {

	@Inject
	private SqlSession sqlSession;
	
	@Override
	public void updatePoint(String sender, int point) {
		Map<String,Object> pm=new HashMap<>();
		//키,값 쌍으로 저장되는 컬렉션 자료구조
		pm.put("sender",sender);//point.xml에서는 키이름만
		//참조하면 값을 가져올수 있다.
		pm.put("point",point);//point키이름에 포인트점수 
		sqlSession.update("pointUp",pm);
		//pointUp은 update 아이디명
	}
}









