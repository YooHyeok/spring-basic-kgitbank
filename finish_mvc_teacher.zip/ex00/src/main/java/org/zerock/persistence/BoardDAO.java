package org.zerock.persistence;

import java.util.List;
import org.zerock.domain.BoardVO;

public interface BoardDAO {

	void insertBoard(BoardVO b);//게시물 저장
	List<BoardVO> getList(BoardVO b);//목록보기
	int getRowCount();//총레코드개수,public abstract이 생략됨.
	void updateHit(int bno);//조회수증가
	BoardVO getBCont(int bno);//내용보기
	void editBoard(BoardVO eb);//게시물 수정
	void deleteBoard(int bno);//게시물 삭제
	void updateReplyCnt(int bno,int amount);
}
