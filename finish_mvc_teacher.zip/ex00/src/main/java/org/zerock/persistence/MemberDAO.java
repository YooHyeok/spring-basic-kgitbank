package org.zerock.persistence;

import org.zerock.domain.MemberVO;

public interface MemberDAO {

	void insertMember(MemberVO m);//회원저장
}
