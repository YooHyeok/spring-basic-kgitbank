package org.zerock.persistence;

import java.util.List;

import org.zerock.domain.GuestVO;

public interface GuestDAO {

	void insertGu(GuestVO g);

	List<GuestVO> getList();

	GuestVO getCont(int g_no);

}
