package org.zerock.persistence;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import org.zerock.domain.MemberVO;

@Repository
public class MemberDAOImpl implements MemberDAO {

	@Inject
	private SqlSession sqlSession;//자동의존성 주입
	//mybatis 쿼리문 실행객체 sqlSession을 생성

	@Override
	public void insertMember(MemberVO m) {
		this.sqlSession.insert("m_in",m);
		/* mybatis 쿼리문 실행메서드(스프링월말평가 문제)
		 *  1.insert():레코드 저장
		 *  2.update():레코드 수정
		 *  3.delete():레코드 삭제
		 *  4.selectOne():단 한개의 레코드를 검색할 때 사용
		 *  5.selectList():하나이상의 레코드를 검색해서 컬렉션
		 *  List로 반환.
		 *  
		 *  m_in은 insert 아이디명
		 */
	}//회원 저장
}



















