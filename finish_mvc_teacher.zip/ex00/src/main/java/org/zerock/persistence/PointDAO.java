package org.zerock.persistence;

public interface PointDAO {

	void updatePoint(String sender,int point);//메시지를
	//보낸 사람에게 포인트 점수 10을 증가
}
