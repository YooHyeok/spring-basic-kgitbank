package org.zerock.persistence;

import java.util.List;

import org.zerock.domain.ReplyVO;

public interface ReplyDAO {

	void addReply(ReplyVO vo);

	List<ReplyVO> listReply(int bno);

	void editReply(ReplyVO vo);

	void delReply(int rno);
	
	int getBno(int rno);//댓글번호를 기준으로 해당 게시물 번호
	//를 알아내기
}
