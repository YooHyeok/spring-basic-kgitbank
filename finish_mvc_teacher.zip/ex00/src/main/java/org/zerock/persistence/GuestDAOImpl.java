package org.zerock.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import org.zerock.domain.GuestVO;

@Repository
public class GuestDAOImpl implements GuestDAO {

	@Inject
	private SqlSession sqlSession;

	@Override
	public void insertGu(GuestVO g) {
      this.sqlSession.insert("guest_in",g);
      //guest_in이 insert 아이디명.
      /* 문제풀이)
       *  1.guest.xml에서 insert 아이디명을 정의하여 저장되게
       *  한다.
       */
	}

	@Override
	public List<GuestVO> getList() {
		return this.sqlSession.selectList("guest_list");
	}//목록보기

	@Override
	public GuestVO getCont(int g_no) {
		return this.sqlSession.selectOne("guest_cont",g_no);
	}
}











