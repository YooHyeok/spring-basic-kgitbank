package org.zerock.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.MediaType;

public class MediaUtils {

	private static Map<String,MediaType> mediaMap;
	//컬렉션 키,값 쌍으로 저장되는 구조인 맵 제네리타입 정적변수
	// 선언
	
	static {
		mediaMap=new HashMap<String,MediaType>();
		mediaMap.put("JPG",MediaType.IMAGE_JPEG);
		mediaMap.put("GIF",MediaType.IMAGE_GIF);
		mediaMap.put("PNG",MediaType.IMAGE_PNG);
	}//정적변수 초기화 블록
	
	public static MediaType getMediaType(String type) {
		return mediaMap.get(type.toUpperCase());
		//get(키이름)메서드로 값을 가져옴.
	}//확장자를 대문자로 가지고 이미지 타입인지를 판단
}


















