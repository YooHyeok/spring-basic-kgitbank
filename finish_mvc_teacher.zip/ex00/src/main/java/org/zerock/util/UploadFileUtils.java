package org.zerock.util;

import java.awt.image.BufferedImage;
import java.io.File;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.UUID;

import javax.imageio.ImageIO;

import org.imgscalr.Scalr;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.FileCopyUtils;

public class UploadFileUtils {

	private static final Logger logger=
LoggerFactory.getLogger(UploadFileUtils.class);
	//STS 콘솔모드로 로그 기록을 위한 로그 객체 생성
	
	public static String uploadFile(String uploadPath,
			String originalName,byte[] fileData)
	throws Exception{
		
		UUID uid=UUID.randomUUID();//의사난수를 발생시키는 객체

String savedName=uid.toString()+"_"+originalName;
//업로드 될 바뀌어진 파일명 구함.
String savedPath=calcPath(uploadPath);// /년/월/일 폴더경로

File target=new File(uploadPath+savedPath,savedName);
// /upload 기본경로에 생성된 폴더에 바뀌어진 첨부파일을 가진
//파일 객체 생성
FileCopyUtils.copy(fileData, target);//바이트 배열 크기 파일로
//실제 업로드

String formatName=originalName.substring(
		originalName.lastIndexOf(".")+1);//첨부한 원본파일로
//부터 확장자를 구함
String uploadedFileName=null;

  if(MediaUtils.getMediaType(formatName) != null) {//이미지
	  //파일이면
	  uploadedFileName=makeThumbnail(uploadPath,
			  savedPath,savedName);//썸네일을 만든다.
  }else {//이미지 파일이 아닌경우
uploadedFileName=makeIcon(uploadPath,savedPath,savedName);	  
  }
		return uploadedFileName;
	}//uploadFile()
	
	private static String makeIcon(String uploadPath,
			String path,String fileName) 
	throws Exception{
	   	String iconName=
uploadPath+path+File.separator+fileName;
	   	
return iconName.substring(
		uploadPath.length()).replace(
				File.separatorChar, '/');
//브라우저에서는 윈도우 경로 '\'를 인식하지 못하기 때문에
//이것을 '/'로 바꾼다.
	}//이미지파일이 아닌 경우 경로 처리를 하는 문자열을 반환
	
	
    //반환값이 오늘날짜 폴더경로+폴더생성
	private static String calcPath(String uploadPath) {
      Calendar cal=Calendar.getInstance();
      String yearPath=File.separator+cal.get(Calendar.YEAR);
      //separator는 시스템에 의존하는 기본 이름 단락문자이다.
      //File.separator는 \,/ 같은 파일의 경로를 분리해준다.
      //윈도우에서는 D:\\upload\test 이런 경로를 각각 구분해 주는
      //역할을 한다. 년도값 경로
      String monthPath=yearPath+File.separator+
new DecimalFormat("00").format(cal.get(Calendar.MONTH)+1);
      // /년도경로/월경로 . 월에 +1을 한이유는 1월이 0으로 반환
      //되기 때문이다.
      String datePath=monthPath+File.separator+
new DecimalFormat("00").format(cal.get(Calendar.DATE));
      // /년도경로/월경로/일경로
      
      makeDir(uploadPath,yearPath,monthPath,datePath);
      //uploadPath 에는 프로젝트에 생성한 이진파일 업로드 기본
      //경로인 upload
      System.out.println("폴더경로:"+datePath);
      
      return datePath;
	}//calcPath()
	
	//오늘날짜 업로드 폴더 생성
	private static void makeDir(String uploadPath,
			String... paths) {
//String... paths은 전달인자 개수를 다르게한 메서드 오버로딩을
//배열로 받는 가변인자문법
		if(new File(paths[paths.length-1]).exists()) {
			//마지막 배열원소값이 존재한다면 참인 경우는
			//오늘날짜 폴더경로가 존재한다는 뜻.
			return;//만들지 않고 해당 메서드가 종료
		}//if
		for(String path:paths) {
			File dirPath=new File(uploadPath+path);
			if(!dirPath.exists()) {//해당 폴더경로가 없다면
				dirPath.mkdir();//해당 경로 생성
			}
		}//향상된for
	}//makeDir()
	
	//원본이미지가 너무 큰 경우 서버로 업로드 하는 속도문제가 발
	//생한다.그러므로 원본이미지를 축소하는 것을 썸네일이라 한다.
	//이미지 축소를 위한 썸네일 만들기
	private static String makeThumbnail(
			String uploadPath,//업로드 기본경로
			String path,// /년/월/일 폴더 경로
			String fileName //업로드 파일이름
			) throws Exception{
		BufferedImage sourceImg=
ImageIO.read(new File(uploadPath+path,fileName));
//실제 이미지가 아닌 메모리상의 이미지를 의미하는 객체 생성
		
		BufferedImage destImg=
Scalr.resize(sourceImg, Scalr.Method.AUTOMATIC,
		Scalr.Mode.FIT_TO_HEIGHT,100);
//원본 파일을 메모리상에 로딩하고,정해진 크기에 맞게 작은 이미지
//파일에 원본 이미지를 복사,FIT_TO_HEIGHT 설정은 썸네일 이미지
//파일의 높이를 뒤에 지정한 100픽셀로 동일하게 만들어 주는 역할

String thumbnailName=
uploadPath+path+File.separator+"s_"+fileName;
//썸네일 이미지 파일명에는 's_'로 시작하도록 설정. 's_'가 아닌
//경우는 썸네일 파일이 아닌 원본 파일명이 된다.

File newFile=new File(thumbnailName);//썸네일 파일 객체 생성
String formatName=
fileName.substring(fileName.lastIndexOf(".")+1);
//확장자를 구함

ImageIO.write(destImg, formatName.toUpperCase(),newFile);
//썸네일을 기록,확장자는 대문자로 바꿈

return 
	thumbnailName.substring(
	uploadPath.length()).replace(File.separatorChar,'/');
//브라우저에서도 윈도우 경로 '\'를 인식하지 못하기 때문에 이것을
//'/'로 바꾼다.
	}//makeThumbnail()
}












































