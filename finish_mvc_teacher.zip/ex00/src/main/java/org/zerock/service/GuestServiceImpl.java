package org.zerock.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.zerock.domain.GuestVO;
import org.zerock.persistence.GuestDAO;

@Service
public class GuestServiceImpl implements GuestService {

	@Inject
	private GuestDAO gDAO;
	
	@Override
	public void insertGu(GuestVO g) {
	  	this.gDAO.insertGu(g);//방명록 저장	
	}

	@Override
	public List<GuestVO> getList() {
		return this.gDAO.getList();
	}

	@Override
	public GuestVO getCont(int g_no) {
		return this.gDAO.getCont(g_no);
	}
}






