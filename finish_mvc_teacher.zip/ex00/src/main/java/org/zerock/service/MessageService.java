package org.zerock.service;

import org.zerock.domain.MessageVO;

public interface MessageService {

	void addMessage(MessageVO vo);
}
