package org.zerock.service;

import java.util.List;

import org.zerock.domain.BoardVO;

public interface BoardService {
/* 비지니스 서비스가 추가하는 이유
 *   1.고객의 요구사항을 반영하는 영역이다.
 *   2.쉽게 말해서 컨트롤과 DAO 사이의 접착제 역할을 한다.
 *   3.고객마다 다른 부분을 처리할 수 있는 완충장치 역할을 한다.
 *   4.트랜잭션 등 처리에서 DAOImpl에 집중되는 비지니스 로직코드를
 *   분산을 해서 분업하게 해주어서 DAO부분 과부하를 줄여주는 효과
 *   가 있다.
 */
	void insertBoard(BoardVO board);
	List<BoardVO> getList(BoardVO b);//목록보기
	int getRowCount();//총레코드 개수
	//void updateHit(int bno);//조회수 증가
	BoardVO getBoardCont(int bno);//내용보기
	void editBoard(BoardVO eb);//게시물 수정
	void deleteBoard(int bno);//게시물 삭제
}

















