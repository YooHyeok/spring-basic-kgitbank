package org.zerock.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.ReplyVO;
import org.zerock.persistence.BoardDAO;
import org.zerock.persistence.ReplyDAO;

@Service 
public class ReplyServiceImpl 
implements ReplyService {

	@Inject
	private ReplyDAO replyDao;
	
	@Inject
	private BoardDAO boardDao;
	
	@Transactional
	@Override
	public void addReply(ReplyVO vo) {
		this.replyDao.addReply(vo);//댓글 추가
		this.boardDao.updateReplyCnt(vo.getBno(),1);
		//새로운 댓글이 추가되면 replycnt컬럼에 댓글개수 카운터
		//가 1증가
	}//트랜잭션 적용

	@Override
	public List<ReplyVO> listReply(int bno) {
		return replyDao.listReply(bno);
	}

	@Override
	public void editReply(ReplyVO vo) {
		replyDao.editReply(vo);		
	}

	@Transactional
	@Override
	public void delReply(int rno) {
		int bno=this.replyDao.getBno(rno);//댓글번호로 게시물
		//번호를 구함
		this.replyDao.delReply(rno);
		this.boardDao.updateReplyCnt(bno,-1);//댓글을 삭제하면
		//댓글 개수가 1감소
	}//트랜잭션 적용
}





























