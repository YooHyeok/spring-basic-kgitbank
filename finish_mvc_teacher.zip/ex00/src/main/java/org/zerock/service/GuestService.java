package org.zerock.service;

import java.util.List;

import org.zerock.domain.GuestVO;

public interface GuestService {

	void insertGu(GuestVO g);

	List<GuestVO> getList();

	GuestVO getCont(int g_no);

}
