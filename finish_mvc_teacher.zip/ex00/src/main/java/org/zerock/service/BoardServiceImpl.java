package org.zerock.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.BoardVO;
import org.zerock.persistence.BoardDAO;

@Service
//스프링에 비지니스 서비스 영역이라는 것을 알려주고 등록
public class BoardServiceImpl implements BoardService {

	@Inject
	private BoardDAO dao;

	@Override
	public void insertBoard(BoardVO board) {
		this.dao.insertBoard(board);
	}

	@Override
	public List<BoardVO> getList(BoardVO b) {
		return dao.getList(b);//this.생략가능
	}

	@Override
	public int getRowCount() {
		return this.dao.getRowCount();
	}

	@Transactional(isolation=Isolation.READ_COMMITTED)
	//트랜잭션 격리(트랜잭션이 처리되는 중간에 외부간섭을 없앰)
	@Override
	public BoardVO getBoardCont(int bno) {
		this.dao.updateHit(bno);
		return this.dao.getBCont(bno);
	}

	@Override
	public void editBoard(BoardVO eb) {
		this.dao.editBoard(eb);		
	}

	@Override
	public void deleteBoard(int bno) {
		this.dao.deleteBoard(bno);	
	}
}















