package org.zerock.service;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.MessageVO;
import org.zerock.persistence.MessageDAO;
import org.zerock.persistence.PointDAO;

@Service
public class MessageServiceImpl implements MessageService {
    
	@Inject
	private MessageDAO messageDAO;
	
	@Inject
	private PointDAO pointDAO;
	
	@Transactional
	@Override
	public void addMessage(MessageVO vo) {
       messageDAO.create(vo);//메시지 추가
       pointDAO.updatePoint(vo.getSender(),10);
       //보낸 사람에게 포인트 점수 10점 업 증가,
       //바로 이부분에서 트랜
       //잭션 적용.만약 포인트점수 업이 실패되면 메시지 추가도
       //rollback 처리되게 한다.
       /* @Transactional 애노테이션 우선순위
        *  1.메서드에 선언한 것이 가장 우선순위가 높다.
        *  2.클래스에 선언한 것이 메서드 다음으로 우선순위가 높다.
        *  3.마지막으로 인터페이스에 선언한 것이 우선순위가 가장
        *  낮다.
        *  일반적인 경우는 클래스나 인터페이스에는 공통적인 규칙
        *  을 선언하고,메서드에는 특별한 설정을 추가하는 경우에
        *  많이 사용된다.
        */
	}
}
















