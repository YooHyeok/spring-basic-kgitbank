package org.zerock.service;

import java.util.List;

import org.zerock.domain.ReplyVO;

public interface ReplyService {

	void addReply(ReplyVO vo);

	List<ReplyVO> listReply(int bno);

	void editReply(ReplyVO vo);

	void delReply(int rno);

}
