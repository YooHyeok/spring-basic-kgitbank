package org.zerock.domain;

import java.util.Date;

public class ReplyVO {//댓글 저장빈 클래스
/* 주의할 것은 테이블 컬럼명과 빈클래스 변수명을 같게
 * 한다. 
 */
	private int rno;//댓글번호
	private int bno;//게시물 번호
	private String replytext;//댓글내용
	private String replyer;//댓글작성자
	private Date regdate;//댓글 등록날짜
	private Date updatedate;//댓글 수정날짜
	/*
	 *  REST 방식을 사용하여 json데이터 객체를 만들면 변수명이
	 *  json데이터의 키이름이 된다.
	 */
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public String getReplytext() {
		return replytext;
	}
	public void setReplytext(String replytext) {
		this.replytext = replytext;
	}
	public String getReplyer() {
		return replyer;
	}
	public void setReplyer(String replyer) {
		this.replyer = replyer;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}
	public Date getUpdatedate() {
		return updatedate;
	}
	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}	
}





