package org.zerock.domain;

public class User {
/*
 * 반드시 테이블 컬럼명과 빈클래스 변수명을 일치시킨다.
 */
	private String uid2;//회원아이디
	private String upw;//회원비번
	private String uname;//회원이름
	private int upoint;//메시지를 남긴 사람에게 포인트 점수 10
	//추가->스프링에서 aop를 통한 트랜잭션 대상
	/* 스프링에서 AOP 개념
	 *  1. AOP는  Aspect Oriented Programming의 약어이다. 스프
	 *  링에서 aop를 사용해서 개발할 때 공통적이고,반복적인 비즈
	 *  니스 로직의 핵심이 아닌 부분을 어떻게 처리하고자 할 경우
	 *  사용된다.
	 *   2.aop와 더불어 데이터 베이스 처리에 가장 중요한 트랜잭션
	 *   처리와 관련된 부분도 함께 진행한다. aop를 통해서 트랜잭
	 *   션을 처리한다.
	 *   
	 *  aop관련 용어 정리
	 *   1.Aspect : 공통 관심사에 대한 추상적인 명칭. 예를 들면
	 *   트랜잭션과 같은 기능.
	 *   2.Advice: 실제 기능을 구현한 클래스 객체 
	 *   3.Join points(조인포인트): 공통 관심사를 적용할 수 있는
	 *   대상. 스프링에서는 각 클래스의 메서드가 이에 해당
	 *   4.Pointcuts(포인트컷):여러 메서드 중 실제 Advice가
	 *   적용될 대상 메서드
	 *   5.target: 대상 메서드를 가지는 객체
	 *   
	 *  aop의 advice 타입 종류
	 *   1.Before Advice: target의메서드 호출전에 적용
	 *   2.After returning : target 메서드 호출후 에 적용
	 *   3.After throwing : target의 예외 발생후 적용
	 *   4.After : target의 메서드 호출 후 예외의 발생에 관계없
	 *   이 적용
	 *   5.Around(가장많이 사용) : target메서드 호출전과 이후
	 *   모두 적용. 
	 */
	public String getUid2() {
		return uid2;
	}
	public void setUid2(String uid2) {
		this.uid2 = uid2;
	}
	public String getUpw() {
		return upw;
	}
	public void setUpw(String upw) {
		this.upw = upw;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public int getUpoint() {
		return upoint;
	}
	public void setUpoint(int upoint) {
		this.upoint = upoint;
	}	
}



















