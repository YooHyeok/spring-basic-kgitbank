package org.zerock.domain;

public class ProductVO {//데이터 저장빈 클래스명
	
	private String name;//이름
	private int price;//가격
	
	public ProductVO(String name,int price) {
		this.name=name;
		this.price=price;//생성자의 주된기능인 멤버변수 초기화
	}//생성자가 오버로딩되면 기본생성자 묵시적 제공을 하지 않음.

	public String getName() {
		return name;
	}

	public int getPrice() {
		return price;
	}

	@Override
	public String toString() {
		return "ProductVO [name="+name+",price="+price+"]";
	}
}







