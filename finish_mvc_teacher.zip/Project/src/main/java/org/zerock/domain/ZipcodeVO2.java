package org.zerock.domain;

public class ZipcodeVO2 {

	private String zipcode;//우편번호
	private String addr;//시도 구군 동
	
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}	
}







