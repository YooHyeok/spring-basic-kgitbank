package org.zerock.dao;

import org.zerock.vo.AdminVO;

public interface AdminDAO {

	AdminVO admin_Login(String admin_id);

}
