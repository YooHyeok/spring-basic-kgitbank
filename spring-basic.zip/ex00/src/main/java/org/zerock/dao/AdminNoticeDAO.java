package org.zerock.dao;

import org.zerock.vo.NoticeVO;

public interface AdminNoticeDAO {

	void insertNotice(NoticeVO n);

}
