package org.zerock.dao;

import org.zerock.vo.MemberVO;

public interface MemberDAO{

	void insertMember(MemberVO m);


}

