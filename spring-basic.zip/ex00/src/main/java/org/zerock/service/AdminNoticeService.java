package org.zerock.service;

import org.zerock.vo.NoticeVO;

public interface AdminNoticeService {

	void insertN(NoticeVO n);

}
