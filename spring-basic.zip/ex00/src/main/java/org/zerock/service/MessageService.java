package org.zerock.service;

import org.zerock.vo.MessageVO;

public interface MessageService {

	void addMessage(MessageVO vo);

}
